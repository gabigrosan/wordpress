<?php

namespace Wpae\Scheduling;


class Config
{
    const TYPE = 'export';
    const API_URL = 'http://scheduling.wpallimport.com/v1';
}